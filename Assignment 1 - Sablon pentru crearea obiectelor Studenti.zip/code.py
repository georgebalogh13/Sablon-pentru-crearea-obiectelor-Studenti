class Student:
    def __init__(self, name, address, phone, course, index_number):
        self.name = name
        self.address = address
        self.phone = phone
        self.course = course
        self.index_number = index_number

    def getInfo(self):
        return "Name: " + self.name + ", address " + self.address + ", Phone : " + self.phone + ", Course : " + self.course + ", Index number : " + str(self.index_number)


john = Student("John Doe", "Bucuresti", "+40768543243", "Python", 433)
mary = Student("Mary Johnson", "New York", "+12463949955", "Javascript", 434)
andrew = Student("Andrew Morgan", "Chicago", "+555 2332 123", "C#", 435)

print(john.getInfo())
print(mary.getInfo())
print(andrew.getInfo())